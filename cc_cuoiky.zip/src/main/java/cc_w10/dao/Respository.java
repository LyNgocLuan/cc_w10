package cc_w10.dao;

import org.springframework.data.repository.CrudRepository;

import cc_w10.model.Content;

public interface Respository extends CrudRepository<Content, Integer>{

}
